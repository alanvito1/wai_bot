import { useState, useEffect } from "react";
import axios from "axios";

function KnowledgeBase() {
    const [data, setData] = useState([]);
    const [pergunta, setPergunta] = useState("");
    const [resposta, setResposta] = useState("");

    useEffect(() => {
        axios.get("http://localhost:5000/api/knowledge")
            .then(response => setData(response.data))
            .catch(error => console.error("Erro ao carregar dados:", error));
    }, []);
const handleDelete = async (id) => {
    try {
        await axios.delete(`http://localhost:5000/api/knowledge/${id}`);
        setData(data.filter(item => item.id !== id)); // Remove da UI
    } catch (error) {
        console.error("Erro ao excluir pergunta:", error);
    }
};
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!pergunta || !resposta) return alert("Preencha todos os campos!");

        try {
            await axios.post("http://localhost:5000/api/knowledge", { pergunta, resposta });
            setData([...data, { pergunta, resposta }]); // Atualiza a UI
            setPergunta("");
            setResposta("");
        } catch (error) {
            console.error("Erro ao adicionar pergunta:", error);
        }
    };

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">📚 Base de Conhecimento</h1>

            {/* Formulário para adicionar perguntas */}
            <form onSubmit={handleSubmit} className="mb-6">
                <input
                    type="text"
                    placeholder="Digite a pergunta..."
                    className="border p-2 w-full mb-2"
                    value={pergunta}
                    onChange={(e) => setPergunta(e.target.value)}
                />
                <textarea
                    placeholder="Digite a resposta..."
                    className="border p-2 w-full mb-2"
                    value={resposta}
                    onChange={(e) => setResposta(e.target.value)}
                />
                <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">Adicionar</button>
            </form>

            {/* Lista de perguntas */}
           <ul>
    {data.map((item) => (
        <li key={item.id} className="border-b p-2 flex justify-between items-center">
            <div>
                <strong>Pergunta:</strong> {item.pergunta} <br />
                <strong>Resposta:</strong> {item.resposta}
            </div>
            <button onClick={() => handleDelete(item.id)} className="bg-red-500 text-white px-2 py-1 rounded">🗑️ Excluir</button>
        </li>
    ))}
</ul>
        </div>
    );
}

export default KnowledgeBase;
