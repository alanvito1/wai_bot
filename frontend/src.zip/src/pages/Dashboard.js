import { useState, useEffect } from "react";
import axios from "axios";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
 
 const [horarios, setHorarios] = useState([]);

useEffect(() => {
    axios.get("http://localhost:5000/api/stats/horarios")
        .then(response => setHorarios(response.data))
        .catch(error => console.error("Erro ao carregar estatísticas de horários:", error));
}, []);

<h2 className="text-xl font-bold mb-2">⏰ Horários de Pico do Chatbot</h2>
<ResponsiveContainer width="100%" height={300}>
    <LineChart data={horarios}>
        <XAxis dataKey="hora" />
        <YAxis />
        <Tooltip />
        <Line type="monotone" dataKey="total" stroke="#82ca9d" />
    </LineChart>
</ResponsiveContainer>
 
function Dashboard() {
    const [stats, setStats] = useState({});
    const [leadsHistory, setLeadsHistory] = useState([]);

    useEffect(() => {
        axios.get("http://localhost:5000/api/stats")
            .then(response => setStats(response.data))
            .catch(error => console.error("Erro ao carregar estatísticas:", error));

        axios.get("http://localhost:5000/api/leads")
            .then(response => {
                const formattedData = response.data.map(lead => ({
                    data: lead.created_at.split(" ")[0], // Apenas a data (sem horário)
                    leads: 1, // Cada lead conta como 1
                }));
                setLeadsHistory(formattedData);
            })
            .catch(error => console.error("Erro ao carregar leads:", error));
    }, []);

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">📊 Dashboard</h1>

            {/* Estatísticas principais */}
            <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="bg-blue-500 text-white p-4 rounded">
                    <h2 className="text-lg">Leads Capturados</h2>
                    <p className="text-2xl">{stats.totalLeads}</p>
                </div>
                <div className="bg-green-500 text-white p-4 rounded">
                    <h2 className="text-lg">Perguntas na Base</h2>
                    <p className="text-2xl">{stats.totalPerguntas}</p>
                </div>
                <div className="bg-yellow-500 text-white p-4 rounded">
                    <h2 className="text-lg">Mensagens Processadas</h2>
                    <p className="text-2xl">{stats.totalMensagens}</p>
                </div>
            </div>

            {/* Gráfico de evolução de leads */}
            <h2 className="text-xl font-bold mb-2">📈 Evolução dos Leads</h2>
            <ResponsiveContainer width="100%" height={300}>
                <BarChart data={leadsHistory}>
                    <XAxis dataKey="data" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="leads" fill="#8884d8" />
                </BarChart>
            </ResponsiveContainer>
			
			
        </div>
    );
}

export default Dashboard;
