import { useState, useEffect } from "react";
import axios from "axios";

function Settings() {
    const [settings, setSettings] = useState({});
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        axios.get("http://localhost:5000/api/settings")
            .then(response => {
                setSettings(response.data);
                setLoading(false);
            })
            .catch(error => console.error("Erro ao carregar configurações:", error));
    }, []);

    const handleSave = async (key, value) => {
        try {
            await axios.post("http://localhost:5000/api/settings", { key, value });
            setSettings({ ...settings, [key]: value });
        } catch (error) {
            console.error("Erro ao salvar configuração:", error);
        }
    };

    if (loading) return <p>Carregando configurações...</p>;

    return (
        <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">⚙️ Configurações</h1>
            {Object.keys(settings).map((key) => (
                <div key={key} className="mb-4">
                    <label className="block font-semibold">{key.replace("_", " ").toUpperCase()}</label>
                    <input
                        type="text"
                        value={settings[key]}
                        onChange={(e) => handleSave(key, e.target.value)}
                        className="border p-2 w-full"
                    />
                </div>
            ))}
        </div>
    );
}

export default Settings;
